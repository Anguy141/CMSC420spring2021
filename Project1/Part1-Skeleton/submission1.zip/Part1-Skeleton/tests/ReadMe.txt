This folder contains sample input and output files.

The main program in Tester.java by default reads from test01-input.txt and
writes to test01-output.txt. You can modify the file name in that file to
read/write to other files (e.g., test02-input.txt, test03-input.txt, ...)

The files test01-expected.txt shows the result of our program in this input.

Note that the file test04-input.txt involves commands that are used only for
Part-b of the assignment.
